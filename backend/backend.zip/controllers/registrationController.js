const db = require('../config/db');

exports.registerForEvent = async (req, res) => {
  const { student_id, event_id } = req.body;

  if (!student_id || !event_id) {
    return res.status(400).json({ message: 'Missing student_id or event_id' });
  }

  try {
    await db.promise().query(
      `INSERT INTO registration (user_id, event_id) VALUES (?, ?)`,
      [student_id, event_id]
    );
    res.status(201).json({ message: 'Registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.checkRegistration = async (req, res) => {
  const { student_id, event_id } = req.query;

  if (!student_id || !event_id) {
    return res.status(400).json({ message: 'Missing student_id or event_id' });
  }

  try {
    const [rows] = await db.promise().query(
      `SELECT * FROM registration WHERE user_id = ? AND event_id = ?`,
      [student_id, event_id]
    );
    if (rows.length > 0) {
      return res.status(200).json({ isRegistered: true });
    } else {
      return res.status(200).json({ isRegistered: false });
    }
  } catch (error) {
    console.error('Error checking registration:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.cancelRegistration = async (req, res) => {


    const { student_id, event_id } = req.body;
  
    console.log(student_id);

    if (!student_id || !event_id) {
      return res.status(400).json({ message: 'Missing student_id or event_id' });
    }
  
    try {
      // Delete the registration from the database
      const [result] = await db.promise().query(
        `DELETE FROM registration WHERE user_id = ? AND event_id = ?`,
        [student_id, event_id]
      );
  
      // Check if the registration was successfully removed
      if (result.affectedRows > 0) {
        return res.status(200).json({ message: 'Registration canceled successfully' });
      } else {
        return res.status(400).json({ message: 'No registration found to cancel' });
      }
    } catch (error) {
      console.error('Error canceling registration:', error);
      return res.status(500).json({ message: 'Server error' });
    }
  };
  
