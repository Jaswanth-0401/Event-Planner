const express = require('express');
const router = express.Router();
const registrationController = require('../controllers/registrationController');

// POST for registering
router.post('/', registrationController.registerForEvent);

// GET for checking registration status
router.get('/check', registrationController.checkRegistration);

// DELETE for canceling registration
router.delete('/cancel', registrationController.cancelRegistration);

module.exports = router;
