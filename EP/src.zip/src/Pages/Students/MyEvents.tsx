import React, { useEffect, useState } from 'react';
import '../../Styles/MyEvents.css';
import EventCard from '../../Components/EventCard';
import SearchBar from '../../Components/SearchBar';

interface Event {
  event_id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  category: string;
  organizerName: string;
}

const MyEvents: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'present' | 'past'>('upcoming');
  const [events, setEvents] = useState<Event[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchUpcomingEvents = async () => {
      if (activeTab !== 'upcoming' || !userId) return;

      setLoading(true);
      try {
        const res = await fetch(`http://localhost:5000/api/registration/upcoming-events?student_id=${userId}`);
        const data = await res.json();

        if (res.ok && Array.isArray(data.events)) {
          setEvents(data.events);
          setError('');
        } else {
          setEvents([]);
          setError('No upcoming events found');
        }
      } catch (err) {
        console.error('Fetch error:', err);
        setError('Failed to load events');
        setEvents([]);
      } finally {
        setLoading(false);
      }
    };

    fetchUpcomingEvents();
  }, [activeTab, userId]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderContent = () => {
    if (activeTab === 'upcoming') {
      return (
        <>
          <SearchBar searchTerm={searchTerm} onSearch={handleSearch} />
          {loading ? (
            <p>Loading upcoming events...</p>
          ) : error ? (
            <p className="error-message">{error}</p>
          ) : filteredEvents.length > 0 ? (
            <div className="event-list">
              {filteredEvents.map(event => (
                <EventCard key={event.event_id} event={event} />
              ))}
            </div>
          ) : (
            <p>No upcoming events found.</p>
          )}
        </>
      );
    }

    if (activeTab === 'present') return <p>Showing present events (coming soon)...</p>;
    if (activeTab === 'past') return <p>Showing past events (coming soon)...</p>;

    return null;
  };

  return (
    <div className="my-events">
      <h2>My Events</h2>

      <div className="toggle-buttons">
        <button className={activeTab === 'upcoming' ? 'active' : ''} onClick={() => setActiveTab('upcoming')}>
          Upcoming
        </button>
        <button className={activeTab === 'present' ? 'active' : ''} onClick={() => setActiveTab('present')}>
          Present
        </button>
        <button className={activeTab === 'past' ? 'active' : ''} onClick={() => setActiveTab('past')}>
          Past
        </button>
      </div>

      <div className="event-section">{renderContent()}</div>
    </div>
  );
};

export default MyEvents;
