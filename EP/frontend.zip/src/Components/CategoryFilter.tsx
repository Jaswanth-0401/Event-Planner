import React from 'react';
import '../Styles/CategoryFilter.css';

interface CategoryFilterProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({ selectedCategory, onCategoryChange }) => {
  const categories = ['All', 'Academic', 'Cultural', 'Hackathon', 'Sports', 'Club', 'Entertainment', 'Career'];

  return (
    <div>
      <select value={selectedCategory} onChange={(e) => onCategoryChange(e.target.value)} className="category-filter">
        {categories.map((category) => (
          <option key={category} value={category}>
            {category}
          </option>
        ))}
      </select>
    </div>
  );
};

export default CategoryFilter;
