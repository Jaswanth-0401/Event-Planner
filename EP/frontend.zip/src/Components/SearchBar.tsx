import React from 'react';
import '../Styles/SearchBar.css';

interface SearchBarProps {
  searchTerm: string;
  onSearch: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, onSearch }) => {
  return (
    <div>
      <input
        type="text"
        placeholder="Search events..."
        value={searchTerm}
        onChange={onSearch}
        className="search-bar"
      />
    </div>
  );
};

export default SearchBar;
