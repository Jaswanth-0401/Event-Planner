import React from 'react';
import { Link } from 'react-router-dom';
import '../Styles/Header.css'

const Header: React.FC = () => {
  const role = localStorage.getItem('role');

  return (
    <header className="header">
      <div className="header-left">
        <h2>Event Planner</h2>
      </div>
      <div className="header-right">
        <Link to={`/${role}/profile`}>Profile</Link>
        <Link to={`/${role}/notifications`}>Notifications</Link>
      </div>
    </header>
  );
};

export default Header;
