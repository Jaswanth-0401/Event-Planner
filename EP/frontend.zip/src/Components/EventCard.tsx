import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../Styles/EventCard.css';

interface Event {
  event_id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  category: string;
  organizerName: string;
}

interface Props {
  event: Event;
}

const EventCard: React.FC<Props> = ({ event }) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    navigate(`/student/event/${event.event_id}`);
  };

  return (
    <div className="event-card">
      <h3>{event.title}</h3>
      <p><strong>Date:</strong> {event.date}</p>
      <p><strong>Time:</strong> {event.time}</p>
      <p><strong>Location:</strong> {event.location}</p>
      <p><strong>Category:</strong> {event.category}</p>
      <p><strong>Organizer:</strong> {event.organizerName}</p>
      <button onClick={handleViewDetails}>View Details</button>
    </div>
  );
};

export default EventCard;
