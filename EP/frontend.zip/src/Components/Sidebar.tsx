import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../Styles/Sidebar.css'

const Sidebar: React.FC = () => {
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    // On initial load, retrieve the role from localStorage
    const storedRole = localStorage.getItem('role');
    setRole(storedRole);
  }, []);  // Empty dependency array ensures this runs once on mount

  if (!role) {
    return <div>Loading...</div>; // Optionally show loading state until role is retrieved
  }

  return (
    <div className="sidebar">
      <ul>
        <li>
          <Link to={`/${role}/home`}>Home</Link>
        </li>
        {role === 'student' ? (
          <>
            <li>
              <Link to="/student/myevents">My Events</Link>
            </li>
            <li>
              <Link to="/student/reminders">Reminders</Link>
            </li>
          </>
        ) : (
          <>
            <li>
              <Link to="/organizer/addevent">Add Event</Link>
            </li>
            <li>
              <Link to="/organizer/myevents">My Events</Link>
            </li>
          </>
        )}
      </ul>
    </div>
  );
};

export default Sidebar;
