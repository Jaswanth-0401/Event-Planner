import React, { useState, useEffect } from 'react';
import SearchBar from '../../Components/SearchBar';
import EventCard from '../../Components/EventCard';
import '../../Styles/MyEvents.css';

interface Event {
  event_id: number;
  title: string;
  date: string;
  location: string;
  organizerName: string;
  category: string;
}

const MyEvents: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [registeredEvents, setRegisteredEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Get the user ID from localStorage (assuming it's stored there after login)
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    if (userId) {
      const fetchRegisteredEvents = async () => {
        try {
          const res = await fetch(`http://localhost:5000/api/registration/events?student_id=${userId}`);
          const data = await res.json();
          if (res.ok) {
            setRegisteredEvents(data.events); // Assuming `data.events` is an array of events
          } else {
            setError('Failed to fetch registered events');
          }
        } catch (err) {
          console.error('Error fetching events:', err);
          setError('Error fetching events');
        } finally {
          setLoading(false);
        }
      };

      fetchRegisteredEvents();
    } else {
      setError('User not logged in');
      setLoading(false);
    }
  }, [userId]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredEvents = registeredEvents.filter(event =>
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="my-events">
      <h2>My Registered Events</h2>

      {/* Search Bar */}
      <div className="search-bar">
        <SearchBar searchTerm={searchTerm} onSearch={handleSearch} />
      </div>

      {/* Event List */}
      {loading ? (
        <p>Loading events...</p>
      ) : error ? (
        <p className="error-message">{error}</p>
      ) : (
        <div className="event-list">
          {filteredEvents.length > 0 ? (
            filteredEvents.map(event => (
              <EventCard key={event.event_id} event={event} />
            ))
          ) : (
            <p className="no-events">No registered events found.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default MyEvents;
