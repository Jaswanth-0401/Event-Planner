import React, { useState } from 'react';
import Modal from 'react-modal'; 
import '../../Styles/Reminders.css'

interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
}

interface Reminder {
  eventId: number;
  reminderTime: string;
  timeLeft: string;
}

const Reminders: React.FC = () => {
  const [events] = useState<Event[]>([
    { id: 1, title: 'Coding Bootcamp', date: '2025-05-01T12:00:00', location: 'Room 101' },
    { id: 2, title: 'Music Concert', date: '2025-05-05T14:00:00', location: 'Auditorium' },
    { id: 3, title: 'Tech Talk', date: '2025-06-12T10:00:00', location: 'Conference Hall' },
  ]);
  
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [selectedReminder, setSelectedReminder] = useState<string>('');
  const [modalIsOpen, setModalIsOpen] = useState<boolean>(false);

  const handleSetReminder = () => {
    if (!selectedReminder || !selectedEvent) return;

    // Calculate the reminder time (minutes before)
    const reminderMinutes = parseInt(selectedReminder.split(' ')[0]);
    const reminderDate = new Date(new Date(selectedEvent.date).getTime() - reminderMinutes * 60000);

    const newReminder: Reminder = {
      eventId: selectedEvent.id,
      reminderTime: selectedReminder,
      timeLeft: `Reminder set for ${selectedReminder} before the event`,
    };

    setReminders([...reminders, newReminder]);
    setModalIsOpen(false); // Close modal after setting the reminder
  };

  const handleDeleteReminder = (eventId: number) => {
    setReminders(reminders.filter((reminder) => reminder.eventId !== eventId));
  };

  return (
    <div className="reminders-page">
      <h2>Set Reminders for Events</h2>

      {/* Events List */}
      <div className="events-container">
        <h3>Events</h3>
        {events.map((event) => (
          <div key={event.id} className="event-item">
            <h4>{event.title}</h4>
            <p>{event.date}</p>
            <p>{event.location}</p>
            <button onClick={() => { setSelectedEvent(event); setModalIsOpen(true); }}>
              Set Reminder
            </button>
          </div>
        ))}
      </div>

      {/* Reminders List */}
      <div className="reminders-container">
        <h3>Reminders</h3>
        {reminders.length > 0 ? (
          reminders.map((reminder, index) => (
            <div key={index} className="reminder-item">
              <p>{reminder.timeLeft} for {events.find(event => event.id === reminder.eventId)?.title}</p>
              <button onClick={() => handleDeleteReminder(reminder.eventId)}>Delete</button>
            </div>
          ))
        ) : (
          <p>No reminders set.</p>
        )}
      </div>

      {/* Modal to set reminder */}
      <Modal isOpen={modalIsOpen} onRequestClose={() => setModalIsOpen(false)} contentLabel="Set Reminder">
        <h3>Set Reminder for {selectedEvent?.title}</h3>
        <select value={selectedReminder} onChange={(e) => setSelectedReminder(e.target.value)}>
          <option value="">Select Reminder Time</option>
          <option value="10 minutes">10 minutes before</option>
          <option value="30 minutes">30 minutes before</option>
          <option value="1 hour">1 hour before</option>
          <option value="2 hours">2 hours before</option>
        </select>
        <button onClick={handleSetReminder}>Set Reminder</button>
        <button onClick={() => setModalIsOpen(false)}>Close</button>
      </Modal>
    </div>
  );
};

export default Reminders;
