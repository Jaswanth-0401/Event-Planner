import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../Styles/Landing.css'; 

const Landing: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-container">
      <header className="landing-header">
        <h1>College Event Planner</h1>
        <p>Discover, track, and attend college events effortlessly</p>
      </header>

      <div className="landing-buttons">
        <button onClick={() => navigate('/login')}>Login</button>
        <button onClick={() => navigate('/register')}>Register</button>
      </div>
    </div>
  );
};

export default Landing;
